var searchData=
[
  ['calculateshade_0',['calculateShade',['../rasterizer_8cpp.html#a1bafb69033d68d0d0911072d4db1e261',1,'rasterizer.cpp']]],
  ['contains_1',['contains',['../structBoundingBox.html#afa7484d1a40fd83c4f9a18d25dfa7f6f',1,'BoundingBox']]]
];
