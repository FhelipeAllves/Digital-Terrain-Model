var searchData=
[
  ['p3_0',['p3',['../structTriangle.html#a5fe0f9efd4d862c3944bc43078e60ffd',1,'Triangle']]],
  ['points_1',['points',['../structMesh.html#a036cde6987388c791c837f8ac78384e5',1,'Mesh']]]
];
