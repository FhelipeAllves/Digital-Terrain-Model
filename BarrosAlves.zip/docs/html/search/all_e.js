var searchData=
[
  ['z_0',['z',['../structPoint.html#a05ba3b1dfcb19430582ae953cbbfbded',1,'Point']]]
];
