var searchData=
[
  ['color_0',['Color',['../structColor.html',1,'']]]
];
